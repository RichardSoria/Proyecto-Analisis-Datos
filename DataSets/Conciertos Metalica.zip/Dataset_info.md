
Dataset has records for all 2221 concerts (as of April 24, 2024) available on https://www.metallica.com/tour/past/
• There are 99 cancelled concerts included into Dataset (as of April 24, 2024). Every such concert represented with 1 row wich have "Is_cancelled"=Yes, "Setlist_no"=1, "Song"= None, "Is_cover"= None
• There are 129 concerts with missing setlists included into Dataset (as of April 24, 2024). Every such concert represented with 1 row wich have "Setlist_no"=1, "Song"= "Setlist is missing", "Is_cover"= None

File separator is semicolon (;) as "Location", "Song_details", "Other_acts", "Tour" columns have comma

Dataset colums description:
Column name - (Data type) (values) text decription

Date - (date) (various) show date in format YYYY-MM-DD
Event - (str) (various, none) present for festivals, TV shows, ceremonies were band appeared
Venue - (str) (various) name of a concert venue 
Location - (str) (various) city, state (for Canada and USA), country
Latitude - (float) (various) location latitude 
Longitude - (float) (various) location longitude 
Is_cancelled - (boolean) (yes, no, none) reflects if show was cancelled 
Setlist_no - (int) (various) song number in show setlist
Song - (str) (various, Setlist is missing, none) song title
Is_cover - (boolean) (yes, no, none) reflects if song author is different from Metallica
Song_details - (str) (various, none) provides additional information about song version
Song_profile_link - (URL) (various, none) song profile link on Metallica.com
Tour - (str) (various, none) Metallica's tour name
Other_acts - (str) (various, none) list of artist attending same event
Concert_details - (str) (various, none) reflects show start time if there are several shows in one day
Concert_profile_link - (URL) (various) concert profile link on Metallica.com